package com.example.SpringProva;

import com.example.SpringProva.Crittografia.Critto;
import com.example.SpringProva.DAO.ProfiloDAO;
import com.example.SpringProva.Inizio.Messaggio;
import com.example.SpringProva.Login.LogIn;
import com.example.SpringProva.Profilo.Profilo;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class ProfiloController {

    //Autowired serve per far capire a Spring che deve fa riferimento alle classi/interfacce degli altri pacchetti
    @Autowired
    private Profilo profilo;

    @Autowired
    ProfiloDAO profiloDAO;

    @Autowired
    LogIn logIn;  //Utilizzata la classe di Log In

    @Autowired
    Critto critto;


    /*
    Semplice metodo per creare un messaggio di benvenuto con un valore di default impostato su Utente
    */
    @GetMapping("/welcome")
    public Messaggio benvenuto(@RequestParam(value = "name", defaultValue = "Utente") String name) {
        return new Messaggio(String.format("Hello %s!", name));
    }


    /*
    Utilizzato PostMapping per postare un oggetto con la personalizzazione dell'HTTP.
    Il ResponseEntity<Object> si usa per dare una personalizzazione al messaggio
    Il RequestBody serve per richiedere cosa postare e in questo caso passiamo l'oggetto profilo
    Abbiamo utilizzato il metodo isValidPassword della classe profilo per effettuare il controllo e ritorniamo un messaggio con:
    HttpStatus.BAD_REQUEST se non va bene
    oppure
    HttpStatus.CREATED se va a buon fine

    ProfiloDao.save è per fare la CRUD del post
     */

    @PostMapping("/aggiungi")
    public ResponseEntity<Object> AggiungiProfilo(@RequestBody Profilo profilo) {
        if (!profilo.isValidPassword(profilo.getPassword())) {
            return new ResponseEntity<>("La password non rispetta i requisiti", HttpStatus.BAD_REQUEST);
        }
        try {
            profilo.setPassword(critto.crittografia(profilo.getPassword()));
        } catch (Exception e) {
            return new ResponseEntity<>("Errore durante la crittografia", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        profiloDAO.save(profilo);
        return new ResponseEntity<>("Oggetto inserito con successo", HttpStatus.CREATED);
    }



    /*
    Qui abbiamo utilizzato il GetMapping per recuperare il profilo
    Abbiamo utilizzato il pathVariable per sostituire {id} con un id esistente direttamente nell'URL.
    Optional<profilo> serve per gestire ed evitare la NullPointerException. è una buona pratica Utilizzarlo perchè il
    findById()vpuò restituire un valore null e quindi utilizzare. Inoltre ti permette di vedere, attraverso il metodo
    isPresent() se l'oggetto è presente o no nel database
     */
    @GetMapping("/profilo/{id}")
    public ResponseEntity<Object> getProfilo(@PathVariable Long id) {
        Optional<Profilo> profilo = profiloDAO.findById(id);
        if (profilo == null) {
            return new ResponseEntity<>("Il profilo con id " + id + " non esiste", HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(profilo, HttpStatus.OK);
    }


    //Metodo del controller per riprendere tutti gli utenti
    @GetMapping("/lista")
    public List<Profilo> listaUtenti() {
        return profiloDAO.findAll();
    }


    /*
    Qui abbiamo fatto il metodo per eliminare un utente con l'id
    Inoltre abbiamo utilizzato il RequestParam per scegliere il parametro da utilizzare per eliminare
    Poi abbiamo messo una ricerca del profilo in base all'id e inserito l'orElse(null)
    L'orElse(null) serve per specificare un valore di default da restituire nel caso in cui l'oggetto non contiene nessun valore
    Poi ho messo che se il profilo è nullo allora mi restituisce un messaggio con lo status notFound
    Altrimenti me lo elimini
     */
    @DeleteMapping("/elimina")
    public ResponseEntity<Object> eliminaProfilo(@RequestParam long id) {
        Profilo profilo = profiloDAO.findById(id).orElse(null);
        if (profilo == null) {
            return new ResponseEntity<>("Il profilo con id " + id + " non esiste", HttpStatus.NOT_FOUND);
        }
        profiloDAO.delete(profilo);
        return new ResponseEntity<>("Il profilo è stato eliminato con successo", HttpStatus.NO_CONTENT);
    }


    @DeleteMapping("/delete/all")
    public ResponseEntity<Object> eliminaTutti(@RequestBody Profilo profilo) {
        profiloDAO.deleteAll();
        return new ResponseEntity<>("La lista è stata eliminata correttamente", HttpStatus.OK);

    }


    /*
    l'utilizzo del metodo HTTP POST per effettuare il login è considerato più sicuro rispetto all'utilizzo del metodo GET
    perché il POST invia i dati del login (ad esempio, username e password) in modo da non essere visibili nell'URL,
    a differenza del GET che li include nella query string dell'URL.
     */
    @PostMapping("/login")
    public ResponseEntity<?> logIn(@RequestBody Profilo profilo) {
// recupera l'utente dal database
        Profilo utente = profiloDAO.findByUsername(profilo.getUsername());  //qui usiamo il metodo profiloDAO.findByUsername in quanto
        // la password deve essere prima decrittografata e quindi devi recuperare solo l'username
        if (utente != null) {
            try {
// decrittografa la password memorizzata
                String decryptedPassword = critto.decrittografia(utente.getPassword());
// confronta la password decrittografata con quella fornita dall'utente
                if (decryptedPassword.equals(profilo.getPassword())) {
                    return new ResponseEntity<>("Benvenuto " + profilo.getUsername(), HttpStatus.OK);
                } else {
                    return new ResponseEntity<>("Credenziali errate", HttpStatus.UNAUTHORIZED);
                }
            } catch (Exception e) {
                return new ResponseEntity<>("Errore durante l'accesso", HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } else {
            return new ResponseEntity<>("Utente non trovato", HttpStatus.NOT_FOUND);
        }
    }
    }





