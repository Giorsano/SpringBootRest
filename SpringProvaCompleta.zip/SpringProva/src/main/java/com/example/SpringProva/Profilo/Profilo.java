package com.example.SpringProva.Profilo;


import jakarta.persistence.*;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;


@Service /*
L'annotazione @Service indica che una classe è un componente a servizio dell'applicazione.
 In Spring, i componenti del livello a servizio permettono l'accesso ai dati e
 alla logica di integrazione con altri componenti dell'applicazione.
 Essa puà essere iniettata in altri bean con @Autowired
*/

@Entity /*
L'annotazione @Entity è un'annotazione di JPA (Java Persistence API) e viene utilizzata per indicare
che una classe rappresenta una tabella del database
*/


@Table(name = "profilo")/*
L'annotazione @Table(name = "") viene utilizzata per specificare il nome della tabella nel database a cui un'entità è mappata.
In altre parole, consente di associare una classe Java ad una tabella specifica nel database.
L'opzione name = "" può essere utilizzata per specificare il nome della tabella, se il nome della classe non corrisponde al nome
della tabella nel database.
*/
public class Profilo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @NonNull /*
    @NonNull è un'annotazione di Spring che può essere utilizzata per assicurare che un parametro non sia null.
    Come @NotBlank, @NonNull può essere utilizzato per assicurare che un valore non sia nullo o vuoto,
    ma vengono utilizzate in contesti diversi.
    @NotBlank viene utilizzata per convalidare i valori delle stringhe,
    mentre @NonNull può essere utilizzata per convalidare qualsiasi tipo di valore.
    */
    private String username;
    @NonNull
    private String password;

   public Profilo (){
   }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Profilo{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                '}';
    }



    //Qui il metodo utilizzato serve per fare il check della password secondo uno standard
    public boolean isValidPassword(String password){
        String pattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,}$";  // questo è il pattern che deve rispettare la password per essere valida
        return password.matches(pattern);
    }


}
