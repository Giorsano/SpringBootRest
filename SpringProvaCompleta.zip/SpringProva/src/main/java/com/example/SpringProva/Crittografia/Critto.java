package com.example.SpringProva.Crittografia;

import org.springframework.stereotype.Service;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;

@Service
public class Critto {
private static final String SECRET_KEY ="1Hbfh667adfDEJ78";  //la key deve essere di 16 caretteri su utilizziamo l'algoritmo AES.
private static final String ALGHORITM = "AES";

public String crittografia(String plainText) throws Exception{  //Il metodo "crittografia" accetta una stringa di testo in chiaro come argomento e utilizza l'algoritmo AES per crittografare il testo.
    SecretKeySpec secretKeySpec = new SecretKeySpec(SECRET_KEY.getBytes(), ALGHORITM); // Crea un oggetto SecretKeySpec utilizzando la chiave segreta specificata e l'algoritmo AES.
    Cipher cipher = Cipher.getInstance(ALGHORITM); // Crea un oggetto Cipher utilizzando l'algoritmo AES.
    cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec); // Inizializza l'oggetto Cipher per l'operazione di crittografia utilizzando l'oggetto SecretKeySpec creato.
    byte[] cipherText = cipher.doFinal(plainText.getBytes()); //Utilizza l'oggetto Cipher per crittografare il testo in chiaro utilizzando il metodo "doFinal"
    return Base64.getEncoder().encodeToString(cipherText); // Codifica il testo crittografato in una stringa utilizzando Base64.getEncoder().encodeToString e restituisce la stringa codificata
}


public String decrittografia(String CipherText) throws Exception{ // Il metodo "decrittografia" accetta una stringa cifrata e utilizza l'algoritmo AES per decifrare il testo.
    byte[] decodifica = Base64.getDecoder().decode(CipherText); //Decodifica la stringa cifrata in un array di byte utilizzando Base64.getDecoder().decode.
    SecretKeySpec secretKeySpec = new SecretKeySpec(SECRET_KEY.getBytes(), ALGHORITM); //Crea un oggetto SecretKeySpec utilizzando la chiave segreta specificata e l'algoritmo AES.
    Cipher cipher = Cipher.getInstance(ALGHORITM); // Crea un oggetto Cipher utilizzando l'algoritmo AES.
    cipher.init(Cipher.DECRYPT_MODE, secretKeySpec); //Inizializza l'oggetto Cipher per l'operazione di decrittografia utilizzando l'oggetto SecretKeySpec creato.
    byte[] plainText = cipher.doFinal(decodifica); //Utilizza l'oggetto Cipher per decifrare il testo crittografato utilizzando il metodo "doFinal".
    return new String(plainText); // Restituisce il testo in chiaro decifrato come una nuova stringa.
}

//

}
