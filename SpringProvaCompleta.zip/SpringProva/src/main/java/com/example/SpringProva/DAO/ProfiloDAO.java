package com.example.SpringProva.DAO;

import com.example.SpringProva.Profilo.Profilo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/*
Questa interfaccia che estende JpaRepository che prende come generici il profilo e il Long dell'ID
Serve per poter effettuare le crud
Qui non abbiamo utilizzato @Service in quanto viene già considerata di servizio e ha metodi per accedere ai dati
 */
@Repository
public interface ProfiloDAO extends JpaRepository<Profilo, Long> {


    /*
    metodo utilizzato per cercare l'utente in base all'username e alla password.
    Spring Data JPA utilizzerà questo metodo per generare automaticamente la query SQL per recuperare i dati dal database
     */
    Profilo findByUsernameAndPassword(String username, String password);

    Profilo findByUsername(String username);
}
