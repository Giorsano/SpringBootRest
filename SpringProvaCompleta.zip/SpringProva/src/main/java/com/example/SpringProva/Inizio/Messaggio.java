package com.example.SpringProva.Inizio;



public class Messaggio {
    private String messaggio;


    public Messaggio(String messaggio){
        this.messaggio = messaggio;
    }

    public String getMessaggio() {
        return messaggio;
    }

    public void setMessaggio(String messaggio) {
        this.messaggio = messaggio;
    }

    @Override
    public String toString() {
        return "Messaggio{" +
                "messaggio='" + messaggio + '\'' +
                '}';
    }
}
