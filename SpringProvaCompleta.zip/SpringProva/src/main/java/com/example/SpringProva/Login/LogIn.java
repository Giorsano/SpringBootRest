package com.example.SpringProva.Login;

import com.example.SpringProva.DAO.ProfiloDAO;
import com.example.SpringProva.Profilo.Profilo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LogIn {
    @Autowired
    ProfiloDAO profiloDAO;

    public Profilo verificaCredenziali(String username, String password){
        return profiloDAO.findByUsernameAndPassword(username, password);  //il .findByUsernameAndPassword è stato creato in ProfiloDao
    }
}
